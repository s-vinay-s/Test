To run the test cases

//Eclipse 

Go to Run configurations as a junit

Select TestRunner as JUnit 5

select Project as "TestProject"
select Test Class as "Runner"

then select the Test Method which needs to be executed (Blank in case of all methods)

Finally apply and Run
