
import java.time.Duration;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Runner {

	WebDriver driver = new ChromeDriver();
	public Runner() throws Exception {
		super();

	}

	@BeforeEach  // The code to execute the preconditions of the test case.
	public void startTest() throws Exception {	
		driver.get("https://www.entrata.com/");
		driver.manage().window().maximize();
		driver.switchTo().defaultContent();

		driver.findElement(By.id("adroll_allow_all")).click();
		driver.switchTo().defaultContent();
		driver.findElement(By.id("rcc-confirm-button")).click();
	}

	
	//Trying to invalid SIGN IN
		@Test
		public void invalidSignInAsPropertyManager() throws Exception
		{
			try {
				driver.findElement(By.xpath("//*[@class='button-default outline-dark-button']")).click();
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
				wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath("//*[@class='button-default solid-dark-button']")))); 
				//
				driver.findElement(By.xpath("//*[@class='button-default solid-dark-button']")).click();
				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@name='company_user[username]']"))));

				//Entering username and password
				driver.findElement(By.xpath("//*[@name='company_user[username]']")).sendKeys("Vinay");

				driver.findElement(By.xpath("//*[@name='company_user[password]']")).sendKeys("Hello");

				driver.findElement(By.xpath("//*[@type='submit']")).click();

				wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@class='login-errors']"))));
				String Error_msg=driver.findElement(By.xpath("//*[@class='login-errors']")).getText();
				System.out.println(" -- "+Error_msg);

				//Validating Error message
				Assertions.assertEquals("The username and password provided are not valid. Please try again.",Error_msg);
			}
			catch(Exception e)
			{
				System.out.println(" Exception in Invalid Login case as Propperty Manager");
				e.printStackTrace();
			}

		}


	//Summit 2024 Register Now
	@Test
	public void registerForSummit2024() throws Exception
	{

		try {

			driver.findElement(By.xpath("//*[@title='Summit 2024 Register Now']")).click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='header-button w-button']"))); // instead of id you can use cssSelector or xpath of your element.

			driver.findElement(By.xpath("//*[@class='header-button w-button']")).click();

			String originalWindow = driver.getWindowHandle();
			for (String windowHandle : driver.getWindowHandles()) {
				if(!originalWindow.contentEquals(windowHandle)) {
					driver.switchTo().window(windowHandle);
					break;
				}
			}
			Thread.sleep(3000);
			driver.switchTo().defaultContent();



			switchToFrameByXpath("//*[@aria-label='First Name']");
			//filling the personal information	
			driver.findElement(By.xpath("//*[@aria-label='First Name']")).sendKeys("Vinay");

			driver.findElement(By.xpath("//*[@aria-label='Last Name']")).sendKeys("Suryawanshi");

			driver.findElement(By.xpath("//*[@aria-label='Company']")).sendKeys("Dassault Systemes");

			driver.findElement(By.xpath("//*[@aria-label='Title']")).sendKeys("Automation");

			driver.findElement(By.xpath("//*[@aria-label='Email Address']")).sendKeys("vinay090897@gmail.com");

			driver.findElement(By.xpath("//*[@aria-label='Mobile']")).sendKeys("8007568809");

			//Validating whether Next button is visible means information is ready to submit/proceed further 
			Assertions.assertTrue(driver.findElement(By.xpath("//*[@id='forward']")).isDisplayed(), "Button available");

		}
		catch(Exception e)
		{
			System.out.println(" Exception in Summit Registration");
			e.printStackTrace();
		}
	}

	//Understanding the resident portal 
	@Test
	public void understandResidentPortal() throws Exception
	{
		try {
			
			//navigation
			driver.findElement(By.xpath("//*[contains(text(),'Products')]/parent::div[@class='header-nav-item']")).click();
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.presenceOfElementLocated((By.xpath("//*[contains(text(),'ResidentPortal')]")))); 

			driver.findElement(By.xpath("//*[contains(text(),'ResidentPortal')]")).click();
			Thread.sleep(5000);
			Assertions.assertTrue(driver.findElement(By.cssSelector("svg.video-button")).isDisplayed(), "Video Button is available to understand about regarding resident portal");
			driver.findElement(By.cssSelector("svg.video-button")).click();
		}	
		catch(Exception e)
		{
			System.out.println(" Exception in understanding Resident Portal");
			e.printStackTrace();
		}


	}

	
	public WebElement switchToFrameByXpath(String xpath) throws Exception {
		try {
			driver.switchTo().defaultContent();
			int size = driver.findElements(By.tagName("iframe")).size();

			for (int i = 0; i < size; i++) {
				driver.switchTo().defaultContent();
				driver.switchTo().frame(i);

				if (driver.findElements(By.xpath(xpath)).size() > 0)
					break;
			}
			return driver.findElement(By.xpath(xpath));

		} catch (Exception e) {

			e.printStackTrace();
			throw new Exception("Could not find given xpath");
		}
	}

	// The code to execute the postconditions of the test case such as ending the test.
	@AfterEach		
	public void endTest() throws Exception {
		driver.quit();
	}


}
